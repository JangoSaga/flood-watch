"use client"

import DamageHeatmap from "../floodguard/components/damage-heatmap"

export default function SyntheticV0PageForDeployment() {
  return <DamageHeatmap />
}